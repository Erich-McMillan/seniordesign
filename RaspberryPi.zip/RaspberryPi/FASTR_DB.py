import sqlite3
import numpy as np
import io

###########################################################
#ContactDatabase Class                                    #
#Facilitates creation of and management of contact DB     #
###########################################################

class ContactDatabase(object):
    def __init__(self):
        contact_table = """ CREATE TABLE IF NOT EXISTS contacts (
                            contact_id integer PRIMARY KEY,
                            name text,
                            job text,
                            face_encoding_0 nparray,
                            face_encoding_1 nparray,
                            face_encoding_2 nparray,
                            face_encoding_3 nparray,
                            face_encoding_4 nparray,
                            face_encoding_5 nparray,
                            face_encoding_6 nparray,
                            face_encoding_7 nparray,
                            face_encoding_8 nparray,
                            face_encoding_9 nparray,
                            face_encoding_10 nparray,
                            face_encoding_11 nparray
                            );"""
        self.conn = sqlite3.connect(r"./database/FASTRcontacts.db", detect_types=sqlite3.PARSE_DECLTYPES)
        #self.conn.execute('pragma foreign_keys = on')
        #self.conn.commit()
        self.cur = self.conn.cursor()
        self.cur.execute(contact_table)
        self.conn.commit()

    #allows for exectuion of SQL string
    # def query(self, arg):
    #     self.cur.execute(arg)
    #     self.conn.commit()d
    #     return self.cur

    def contact_new(self):
        contact = """   INSERT INTO contacts (
                        name,
                        job,
                        face_encoding_0,
                        face_encoding_1,
                        face_encoding_2,
                        face_encoding_3,
                        face_encoding_4,
                        face_encoding_5,
                        face_encoding_6,
                        face_encoding_7,
                        face_encoding_8,
                        face_encoding_9,
                        face_encoding_10,
                        face_encoding_11)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) """
        contact_data_blank = (None, None, None, None, None, None, None, None, None, None, None, None, None, None)
        self.cur.execute(contact, contact_data_blank)
        self.conn.commit()
        #not sure if the return below will work as expected
        self.cur.execute("""SELECT contact_id FROM contacts
        					WHERE contact_id = (SELECT MAX(contact_id)  FROM contacts)""")
        #retun primary key for new user
        return self.cur.fetchone()

    def contact_delete(self, contact_id):
        sql =   """ DELETE FROM contacts 
                    WHERE contact_id = ?"""
        self.cur.execute(sql, (contact_id,))
        self.conn.commit()

    def contact_addName(self, contact_id, name):
        sql =   """ UPDATE contacts
                    SET name = ?
                    WHERE contact_id = ?"""
        self.cur.execute(sql, (name, contact_id))
        self.conn.commit()

    def contact_getName(self, contact_id):
        sql =   """ SELECT name
                    FROM contacts
                    WHERE contact_id = ?"""
        self.cur.execute(sql, (contact_id,))
        name = self.cur.fetchone()
        return name

    def contact_addJob(self, contact_id, job):
        sql =   """ UPDATE contacts
                    SET job = ?
                    WHERE contact_id = ?"""
        self.cur.execute(sql, (job, contact_id))
        self.conn.commit()

    def contact_getJob(self, contact_id):
        sql =   """ SELECT job
                    FROM contacts
                    WHERE contact_id = ?"""
        self.cur.execute(sql, (contact_id,))
        job = self.cur.fetchone()
        return job

    def contact_addFace(self, contact_id, facenumber, encoding):
        sql =   """ UPDATE contacts
                    SET face_encoding_%s = ?
                    WHERE contact_id = ?""" % facenumber
        self.cur.execute(sql, (encoding, contact_id))
        self.conn.commit()
        
    def contact_getFace(self, contact_id, facenumber):
        sql =   """ SELECT face_encoding_%s 
                    FROM contacts
                    WHERE contact_id = ?""" % facenumber
        self.cur.execute(sql, (contact_id,))
        encoding = self.cur.fetchone()[0]
        return encoding

    def contact_listAll(self):
        sql =   """ SELECT contact_id, name
                    FROM contacts"""
        self.cur.execute(sql)
        contacts = self.cur.fetchall()
        return contacts

    def __del__(self):
        self.conn.close()



###########################################################
#The functions in this section register a new             #
#type, "nparray", to sqlite3.                             #
###########################################################

def adapt_array(arr):
    out = io.BytesIO()
    np.save(out, arr)
    out.seek(0)
    return sqlite3.Binary(out.read())

def convert_array(text):
    out = io.BytesIO(text)
    out.seek(0)
    return np.load(out)

#convert np.array to text when inserting to sqlite3 db
sqlite3.register_adapter(np.ndarray, adapt_array)

#convert text to np.array when selecting from sqlite3 db
sqlite3.register_converter("nparray", convert_array)


import FASTR_DB
import numpy as np

x = np.arange(12).reshape(2,6)

mycontacts = FASTR_DB.ContactDatabase()

mycontacts.contact_new()
mycontacts.contact_new()
mycontacts.contact_new()

#mycontacts.contact_delete(2)

mycontacts.contact_addName(1, 'Jordan Fail')

mycontacts.contact_addJob(1, "Sysadmin")

mycontacts.contact_addFace(1, 1, x)

encoding = mycontacts.contact_getFace(1, 3)

print (encoding)

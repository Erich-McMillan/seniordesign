'''*********************************************************************************

Transcription Demo for ECE 4335 Senior Design Project
Team 13: Jordan Fail, Erich McMillan, Charles Asquith, Benjamin Nelson
Fall 2017 Semester

*********************************************************************************'''

import speech_recognition

while True:

    #raw_input("Press 'Enter' to begin recording audio...")

    recognizer = speech_recognition.Recognizer()

    with speech_recognition.Microphone() as source:
        print ("Ok, start talking now.")
        recording = recognizer.listen(source)

    #convert recording to transcription
    try:
        print("We think you said:  " + recognizer.recognize_google(recording) + "\n")
    except speech_recognition.UnknownValueError:
        print("We couldn't understand what you said there.")
    except speech_recognition.RequestError as e:
        print("Could not request results from Google Cloud Speech service; {0}".format(e))

print ("\n")

'''*********************************************************************************

Transcription Demo for ECE 4335 Senior Design Project
Team 13: Jordan Fail, Erich McMillan, Charles Asquith, Benjamin Nelson
Fall 2017 Semester

*********************************************************************************'''

import speech_recognition
import Tkinter
import tkMessageBox
from Tkinter import *

#define window for user control of speech transcription
top = Tkinter.Tk()
message = StringVar()
#speach transcription function
def getSpeechTrans():

    # call the microphone
    recognizer = speech_recognition.Recognizer()
    with speech_recognition.Microphone() as source:
        #start recording
        recording = recognizer.listen(source)

    #convert recording to transcription
    #attempt transcription
    try:
        tkMessageBox.showinfo( "Transcription Result", recognizer.recognize_google(recording))
    #error message if no valid speech is detected or speech unclear
    except speech_recognition.UnknownValueError:
        tkMessageBox.showinfo("Transcription Error", "We couldn't understand what you said there.")
    #error message if script can't reach google server
    except speech_recognition.RequestError:
        tkMessageBox.showinfo("Connection Error", "Could not connect to speech server.")

#definitions for window elements
button = Tkinter.Button(top, text = "START", command = getSpeechTrans)
label = Label(top, textvariable = message)

#build gui window
message.set("Welcome to the FASTR speach transcriber demo.\nTo begin a transcription, click START below.")
label.pack()
button.pack()
top.mainloop()
'''*********************************************************************************

Transcription Demo for ECE 4335 Senior Design Project
Team 13: Jordan Fail, Erich McMillan, Charles Asquith, Benjamin Nelson
Fall 2017 Semester

*********************************************************************************'''

import speech_recognition
import tkinter
from tkinter import *

#define window for user control of speech transcription
top = tkinter.Tk()
message = StringVar()
#speach transcription function
def getSpeechTrans():


    print (speech_recognition.Microphone())
    # call the microphone
    recognizer = speech_recognition.Recognizer()
    with speech_recognition.Microphone() as source:
        #start recording
        recording = recognizer.listen(source)

    #convert recording to transcription
    #attempt transcription
    try:
        tkinter.messagebox.showinfo( "Transcription Result", recognizer.recognize_google(recording))
    #error message if no valid speech is detected or speech unclear
    except speech_recognition.UnknownValueError:
        tkinter.messagebox.showinfo("Transcription Error", "We couldn't understand what you said there.")
    #error message if script can't reach google server
    except speech_recognition.RequestError:
        tkinter.messagebox.showinfo("Connection Error", "Could not connect to speech server.")

#definitions for window elements
button = tkinter.Button(top, text = "START", command = getSpeechTrans)
label = Label(top, textvariable = message)

#build gui window
message.set("Welcome to the FASTR speach transcriber demo.\nTo begin a transcription, click START below.")
label.pack()
button.pack()
top.mainloop()

# Jordan Fail && Erich McMillan
# 24 April 2018
# This program will perform all necessary functions needed for the 
# server side of the FASTR project including:
#	1. Load image files from the pi when startrec.txt received
#   	a. the timestamp is read from startrec.txt
#	2. Read image_i_timestamp.jpeg
#	3. Perform facial encoding and recognition on the image_i...
#		a. if face is recognized obtain name from database and move to 
# 			step 5.
#		b. if face is not recognized move to step 2 and continue
#			until 5 faces are encoded then move to step 4
#	4. Obtain audio recording from pi and process it for names
#		a. if name is obtained create a new profile with the 5 encodings
#			from steps 2 and 3 and the name obtained. Move to step 5.
#		b. if no name then move to step 6.
#	5. Use text to speech to convert name to speech then send audio file
#		to pi for user playback. Move to step 7.
#	6. Use text to speech to convert "no name found" to audio and send 
#		audio to pi for user playback move to step 7.
#	7. DONE: go back to wait loop in step 1

###### IMPORTS   ######
import os
import sys
import pysftp
import time

# For Database
import FASTR_DB

# For face rec
import face_recognition
import scipy
import numpy as np

# For speech
from gtts import gTTS
import speech_recognition


###### FUNCTIONS ######
def sftpLogin(hostIP, username, password):
	# definition: Will log current shell into the raspberry pi for file
	#	tranfers. Will also return a pysftp object on sucess
	# inputs: 
	#	hostIP: (string) the host ip address as a IP string xxx.xx.xx.xx
	#	username: (string) the user to login as
	# outputs:
	#	Upon sucess will return a pysftp object which is logged into the
	#   remote host. Upon failure will return -1
	
	try:
		srv = pysftp.Connection(host=hostIP, username=username, password=password)
	except: 
		# error no connection made
		print('Error connecting to host: ' + hostIP)
		return -1
	return srv
	
def sftpLogout(sftpObj):
	# definition: will logout sftpObj
	# inputs:
	# 	sftpObj: (pysftp object) the object to be logged out
	# outputs:
	#	no returns
	sftpObj.close()
	
def loginToPi():
	# definition: will ask for pi ip then log in and move to project directory
	# inputs:
	# 	from-user: (str) type the ip address of pi on LAN
	# outputs:
	#	returns the sftp object for later use
	
	piIP = input("enter the pi IP: ")
	#piIP = '172.25.19.116'
	piShell = sftpLogin(piIP,'pi','raspberry')
	if(piShell == -1):
		print("Error logging into pi")
		sys.exit()
	
	piShell.chdir('Desktop/fastr/new_scan')
	print(piShell.pwd)
	return piShell
	
def waitForStartFile(sftpObj):
	# definition: waits until startrec.txt appears in current folder then return
	#	the timestamp
	# inputs:
	# 	piShell: (pysftp object) the object to be logged out
	# outputs:
	#	returns the timestamp
	while(piShell.isfile('startrec.txt') == False):
		time.sleep(0.01)
		
	###open file and get timestamp
	piShell.get('startrec.txt')
	with open ('startrec.txt', 'r') as startfile:
		timestamp=startfile.read().strip(' \t\n\r')
		print(timestamp)
	return timestamp

def textToAudio(text2conv, timestamp):
    # definition: will convert text to speech and save into a wave file
    # inputs:
    #  text2conv: (string) a string which will be converted to speech
    #  timestamp: (string) the timestamp for the file
    # outputs:
    #  will create a wave file containing the audio and return the audio file name for uploading
     
    tts = gTTS(text=text2conv, lang='en')
    filename = 'response_' + timestamp
    tts.save(filename + '.mp3')
    return filename

def audioToText(audiofilename):
    # definition:
    recognizer = speech_recognition.Recognizer()
    with speech_recognition.AudioFile(audiofilename) as source:
    	recording = recognizer.record(source)
    try:
    	return recognizer.recognize_google(recording)
    except:
    	return -1
def textParsing():
    # definition
    print('write textParsing()')

###### MAIN      ######

mycontacts = FASTR_DB.ContactDatabase()
piShell = loginToPi()
#x=True
while(True):
	print('start round')
	#x=False
	#print('start main loop')
	timestamp = waitForStartFile(piShell)
	print(timestamp)
	newContactID = mycontacts.contact_new()[0]
	print ('New contact ID: ' + str(newContactID))
	bestMatch = (0, 0)
	i = 0
	matchFound = False
	badContact = False
	while(i < 5):
		filename = 'image_' + str(i) + '_' + str(timestamp) + '.jpeg'
		#print(filename)
		if(piShell.isfile(filename)):
			print('starting rec')
			print(piShell.pwd)
			piShell.get(filename)
			image = face_recognition.load_image_file(filename)
			
			## If new image contains a face, store and check against DB
			if (len((face_recognition.face_encodings(image))) > 0):
				print (filename + ': face found')
				image_encode = face_recognition.face_encodings(image)[0]
				mycontacts.contact_addFace(newContactID, i, image_encode)
				## Check if new pic matches existing database contact
				for j in range(1, newContactID):
					#print('j = ' + str(j))
					currentMatch = 0
					for k in range(0, 5):
						faceToCheck = (mycontacts.contact_getFace(j, k))
						tempCompare = face_recognition.compare_faces([faceToCheck], image_encode)
						#print('Checking (' + str(j) + ',' + str(k) + '): ' + str(tempCompare[0]))
						if (tempCompare[0]):
							currentMatch = currentMatch + 1;
					#print(str(currentMatch) + ' matches with contact ' + str(j))
					#print('currentMatch = ' + str(currentMatch))
					#print('bestMatch = (' + str(bestMatch[0]) + ',' + str(bestMatch[1]) + ')')
					if (currentMatch > bestMatch[1]):
						bestMatch = (j, currentMatch)
			
			## If no face, print and skip
			else:
				print (filename + ': face not found')
			
			if (i == 4):
				print('Varify new images')
				faceCheckArray = [0,0,0,0,0]
				validIndex = -1
				for a in range(0, 5):
					faceToVerify = mycontacts.contact_getFace(newContactID, a)
					print(type(faceToVerify))
					print(type(faceToVerify) is np.ndarray)
					if (type(faceToVerify) is np.ndarray):
						faceCheckArray[a] = 1
						print(faceCheckArray)
						validIndex = a
				print(validIndex)
				if (validIndex != -1):
					print('entered inner loop')
					faceToCopy = mycontacts.contact_getFace(newContactID, validIndex)
					for b in range(0, 5):
						if (faceCheckArray[b] == 0):
							mycontacts.contact_addFace(newContactID, b, faceToCopy)
							faceCheckArray[b] = 1
				else:
					mycontacts.contact_delete(newContactID)
					bestMatch = (0,0)
					badContact = True
								
			## matching case: print name (later replace with return name.wav)
			if (bestMatch[1] >= 3):
				print('image_' + str(i) + ' matches contact: ' + str((mycontacts.contact_getName(bestMatch[0]))[0]))
				mycontacts.contact_delete(newContactID)
				matchFound = True
				break
			
			i = i+1
	
	## Start Audio
	print(badContact)
	if (badContact):
		print('Bad contact')
		name = 'Bad contact'
		print(name)
		audiofilename = textToAudio(name, timestamp)
		os.system('ffmpeg -i ' + audiofilename+'.mp3' + ' ' + audiofilename + '.wav')
		piShell.chdir('../scan_response')
		piShell.put(audiofilename+'.wav')
		piShell.chdir('../new_scan')
		time.sleep(3)
	elif (matchFound):
		print('Found existing contact')
		name = str((mycontacts.contact_getName(bestMatch[0]))[0])
		print(name)
		audiofilename = textToAudio(name, timestamp)
		os.system('ffmpeg -i ' + audiofilename+'.mp3' + ' ' + audiofilename + '.wav')
		piShell.chdir('../scan_response')
		piShell.put(audiofilename+'.wav')
		piShell.chdir('../new_scan')
		time.sleep(3)
	else:
		print('Make new contact')
		piShell.get('audio_' + timestamp + '.wav')
		print('audio_' + timestamp + '.wav')
		name = audioToText('audio_' + timestamp + '.wav')
		if name == -1:
			name = timestamp
		print(name)
		mycontacts.contact_addName(newContactID, name)
		print(str((mycontacts.contact_getName(newContactID))[0]))
		audiofilename = textToAudio('New contact created for ' + name, timestamp)
		os.system('ffmpeg -i ' + audiofilename+'.mp3' + ' ' + audiofilename + '.wav')
		piShell.chdir('../scan_response')
		piShell.put(audiofilename+'.wav')
		piShell.chdir('../new_scan')
		time.sleep(3)
	




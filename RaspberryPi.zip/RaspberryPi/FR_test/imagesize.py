import face_recognition
import cv2
import scipy


# load face image files
jordan1 = face_recognition.load_image_file("jordan1.jpg")
charles1 = face_recognition.load_image_file("charles1.jpg")
erich1 = face_recognition.load_image_file("erich1.jpg")
ben1 = face_recognition.load_image_file("ben1.jpg")
pei1 = face_recognition.load_image_file("pei1.jpg")
ethan1 = face_recognition.load_image_file("ethan1.jpg")

#jordan1_tuple = jordan1.shape
#if jordan1_tuple[0] > jordan1_tuple[1]

print (len((face_recognition.face_encodings(erich1))))

if len((face_recognition.face_encodings(erich1))) > 0:
    print ("erich1.jpg: face found")
    erich1_encode = face_recognition.face_encodings(erich1)[0]
else: print ("erich1.jpg: face not found")

if (max(jordan1.shape[0], jordan1.shape[1]) > 640):
    jordan1 = scipy.misc.imresize(jordan1, 640/(max(jordan1.shape[0], jordan1.shape[1])))

if (max(charles1.shape[0], charles1.shape[1]) > 640):
    charles1 = scipy.misc.imresize(charles1, 640/(max(charles1.shape[0], charles1.shape[1])))

if (max(erich1.shape[0], erich1.shape[1]) > 640):
    erich1 = scipy.misc.imresize(erich1, 640/(max(erich1.shape[0], erich1.shape[1])))

if (max(ben1.shape[0], ben1.shape[1]) > 640):
    ben1 = scipy.misc.imresize(ben1, 640/(max(ben1.shape[0], ben1.shape[1])))

if (max(pei1.shape[0], pei1.shape[1]) > 640):
    pei1 = scipy.misc.imresize(pei1, 640/(max(pei1.shape[0], pei1.shape[1])))

if (max(ethan1.shape[0], ethan1.shape[1]) > 640):
    ethan1 = scipy.misc.imresize(ethan1, 640/(max(ethan1.shape[0], ethan1.shape[1])))




print (jordan1.shape)
print (charles1.shape)
print (erich1.shape)    
print (ben1.shape)
print (pei1.shape)
print (ethan1.shape)

print (face_recognition.face_encodings(jordan1)[0])

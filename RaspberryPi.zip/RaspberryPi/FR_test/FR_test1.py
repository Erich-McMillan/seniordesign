import face_recognition

jordan1 = face_recognition.load_image_file("jordan1.jpg")
jordan2 = face_recognition.load_image_file("jordan2.jpg")
charles1 = face_recognition.load_image_file("charles1.jpg")
jordan_glasses = face_recognition.load_image_file("jordan_glasses.jpg")
jordan_shades = face_recognition.load_image_file("jordan_shades.jpg")

jordan1_encode[]

jordan1_encode[0] = face_recognition.face_encodings(jordan1)[0]
jordan1_encode[1] = face_recognition.face_encodings(jordan2)[0]
charles1_encode = face_recognition.face_encodings(charles1)[0]
jordan1_encode[2] = face_recognition.face_encodings(jordan_glasses)[0]
jordan1_encode[3] = face_recognition.face_encodings(jordan_shades)[0]


#jordan_v_jordan = face_recognition.compare_faces([jordan1_encode], jordan2_encode)
jordan_v_charles = face_recognition.compare_faces([jordan1_encode], charles1_encode)
#jordan_v_glasses = face_recognition.compare_faces([jordan1_encode], jordan_glasses_encode)
#jordan_v_shades = face_recognition.compare_faces([jordan1_encode], jordan_shades_encode)


#print(jordan_v_jordan)
print(jordan_v_charles)
#print(jordan_v_glasses)
#print(jordan_v_shades)
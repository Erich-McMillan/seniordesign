'''*********************************************************************************

Facial Regognition Demo for ECE 4335 Senior Design Project
Team 13: Jordan Fail, Erich McMillan, Charles Asquith, Benjamin Nelson
Fall 2017 Semester

*********************************************************************************'''


import face_recognition     #library of calls to encode and compare faces (works with cv2)
import cv2                  #face encode and compare engine
import scipy                #library math functions and number manipulation
import scipy.misc

# Get a reference to webcam #0 (the default one)
video_capture = cv2.VideoCapture(0)

# load face image files (hard links for testing)
jordan1 = face_recognition.load_image_file("jordan1.jpg")
charles1 = face_recognition.load_image_file("charles1.jpg")
erich1 = face_recognition.load_image_file("erich1.png")
ben1 = face_recognition.load_image_file("ben1.jpg")
pei1 = face_recognition.load_image_file("pei1.jpg")
ethan1 = face_recognition.load_image_file("ethan1.jpg")


# resize larger images to 480 x 640 for performance
if (max(jordan1.shape[0], jordan1.shape[1]) > 640):
    jordan1 = scipy.misc.imresize(jordan1, 640/(max(jordan1.shape[0], jordan1.shape[1])))

if (max(charles1.shape[0], charles1.shape[1]) > 640):
    charles1 = scipy.misc.imresize(charles1, 640/(max(charles1.shape[0], charles1.shape[1])))

if (max(erich1.shape[0], erich1.shape[1]) > 640):
    erich1 = scipy.misc.imresize(erich1, 640/(max(erich1.shape[0], erich1.shape[1])))

if (max(ben1.shape[0], ben1.shape[1]) > 640):
    ben1 = scipy.misc.imresize(ben1, 640/(max(ben1.shape[0], ben1.shape[1])))

if (max(pei1.shape[0], pei1.shape[1]) > 640):
    pei1 = scipy.misc.imresize(pei1, 640/(max(pei1.shape[0], pei1.shape[1])))


# create encoding form images that contain a face and print feedback
if (len((face_recognition.face_encodings(jordan1))) > 0):
    print ("jordan1.jpg: face found")
    jordan1_encode = face_recognition.face_encodings(jordan1)[0]
else: print ("jordan1.jpg: face not found")

if (len((face_recognition.face_encodings(charles1))) > 0):
    print ("charles1.jpg: face found")
    charles1_encode = face_recognition.face_encodings(charles1)[0]
else: print ("charles1.jpg: face not found")

if (len((face_recognition.face_encodings(erich1))) > 0):
    print ("erich1.jpg: face found")
    erich1_encode = face_recognition.face_encodings(erich1)[0]
else: print ("erich1.jpg: face not found")

if (len((face_recognition.face_encodings(ben1))) > 0):
    print ("ben1.jpg: face found")
    ben1_encode = face_recognition.face_encodings(ben1)[0]
else: print ("ben1.jpg: face not found")

if (len((face_recognition.face_encodings(pei1))) > 0):
    print ("pei1.jpg: face found")
    pei1_encode = face_recognition.face_encodings(pei1)[0]
else: print ("pei1.jpg: face not found")


# initialize variables to handle face lacation mapping in the webcam feed
face_locations = []
face_encodings = []
face_names = []
process_this_frame = True

while True:
    # capture single frame of video
    ret, frame = video_capture.read()

    # resize video to 1/4 size for faster face recognition processing
    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)

    # Only process every other frame of video to save time
    if process_this_frame:
        # Find all the faces and face encodings in the current frame of video
        face_locations = face_recognition.face_locations(small_frame)
        face_encodings = face_recognition.face_encodings(small_frame, face_locations)

        face_names = []
        # check for faces in the current webcam image
        for face_encoding in face_encodings:
            match_jordan1 = face_recognition.compare_faces([jordan1_encode], face_encoding)
            match_charles1 = face_recognition.compare_faces([charles1_encode], face_encoding)
            match_erich1 = face_recognition.compare_faces([erich1_encode], face_encoding)
            match_ben1 = face_recognition.compare_faces([ben1_encode], face_encoding)
            match_pei1 = face_recognition.compare_faces([pei1_encode], face_encoding)

            name = "unknown"
            if match_jordan1[0]:
                name = "Jordan"
            if match_charles1[0]:
                name = "Charles"
            if match_erich1[0]:
                name = "Erich"
            if match_ben1[0]:
                name = "Ben"
            if match_pei1[0]:
                name = "Dr. Pei"

            face_names.append(name)

    process_this_frame = not process_this_frame


    # Display the results
    for (top, right, bottom, left), name in zip(face_locations, face_names):
        # Scale back up face locations since the frame we detected in was scaled to 1/4 size
        top *= 4
        right *= 4
        bottom *= 4
        left *= 4

        # Draw a box around the face
        #cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)

        # Draw a label with a name below the face
        #cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
        font = cv2.FONT_HERSHEY_DUPLEX
        cv2.putText(frame, name, (left + 6, bottom - 6), font, 2.0, (0, 0, 255), 2)

    # Display the resulting image
    cv2.imshow('Video', frame)

    # Hit 'q' on the keyboard to quit
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release handle to the webcam
video_capture.release()
cv2.destroyAllWindows()

import sqlite3
 
def create_db(db_file):
        conn = sqlite3.connect(db_file)
 
if __name__ == '__main__':
    create_db(r"C:\JordaNoneDrive\OneDrive\School\University of Houston Courses\Senior Design Project\Database\test.db")


import sqlite3
import database_functions
import numpy as np

contact_table = """ CREATE TABLE IF NOT EXISTS contacts3 (
    id integer PRIMARY KEY,
    name text,
    job text,
    face_encoding_1 nparray,
    face_encoding_2 text,
    face_encoding_3 text,
    face_encoding_4 text,
    face_encoding_5 text,
    face_encoding_6 text,
    face_encoding_7 text,
    face_encoding_8 text,
    face_encoding_9 text,
    face_encoding_10 text,
    face_encoding_11 text,
    face_encoding_12 text
    );"""

x = np.arange(12).reshape(2,6)

contact_format1 = ''' INSERT INTO contacts(name,job,face_encoding_1,face_encoding_2,face_encoding_3,face_encoding_4, face_encoding_5,
            face_encoding_6,face_encoding_7,face_encoding_8,face_encoding_9,face_encoding_10,face_encoding_11,face_encoding_12)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) '''

contact_format2 = ''' INSERT INTO contacts2(name,job,face_encoding_1,face_encoding_2,face_encoding_3,face_encoding_4, face_encoding_5,
            face_encoding_6,face_encoding_7,face_encoding_8,face_encoding_9,face_encoding_10,face_encoding_11,face_encoding_12)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) '''

contact_format3 = ''' INSERT INTO contacts3(name,job,face_encoding_1,face_encoding_2,face_encoding_3,face_encoding_4, face_encoding_5,
            face_encoding_6,face_encoding_7,face_encoding_8,face_encoding_9,face_encoding_10,face_encoding_11,face_encoding_12)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) '''

contact_1 = ('Jordan Fail', 'IT', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l')

contact_2 = ('Erich McMillan', 'Engineer', 'a', 'b', 'c', 'd', 'e', None, None, 'h', 'i', 'j', 'k', 'l')

contact_3 = ('Ben', 'Tester', x, None, None, None, None, None, None, None, None, None, None, None)


#CAUTION: Hard codded DB location.
conn = sqlite3.connect(r"C:\JordaNoneDrive\OneDrive\School\University of Houston Courses\Senior Design Project\Database\test2.db", detect_types=sqlite3.PARSE_DECLTYPES)
c = conn.cursor()
#c.execute(contact_table)
#c.execute(contact_format3, contact_3)
#conn.commit()

c.execute("SELECT face_encoding_1 FROM contacts3")
temps = c.fetchone()[0]

print(x)
print(type(x))

print(temps)
print(type(temps))


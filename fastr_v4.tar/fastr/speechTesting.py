# Erich McMillan && Jordan Fail
# 26 April 2018
# Will test converting a .wav to text then parsing the text for a name and subsequently converting name text back to
# an audio file for playback

# https://pythonprogramminglanguage.com/text-to-speech/

from gtts import gTTS
import speech_recognition

def textToAudio(text2conv, timestamp):
    # definition: will convert text to speech and save into a wave file
    # inputs:
    #  text2conv: (string) a string which will be converted to speech
    #  timestamp: (string) the timestamp for the file
    # outputs:
    #  will create a wave file containing the audio and return the audio file name for uploading
     
    tts = gTTS(text=text2conv, lang='en')
    filename = 'response_' + timestamp + '.wav'
    tts.save(filename)
    return filename

def audioToText(audiofilename):
    # definition:
    recognizer = speech_recognition.Recognizer()
    source = speech_recognition.AudioFile(audiofilename)
    recognizer.record(source)
    return recognizer.recognize_google(recording)
    
def textParsing():
    # definition
    print('write textParsing()')
    
print(audioToText('test.wav'))

    